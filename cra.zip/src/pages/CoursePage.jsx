import React from "react";
import Course from "../components/PublicComponents/Course";

const CoursePage = () => {


  return (
    <>
      <Course />
    </>
  );
};

export default CoursePage;
