import PopularSection from "../components/PublicComponents/Sections/PopularSection";

const PopularPage = () => {
  return (
    <>
      <PopularSection />
    </>
  );
};

export default PopularPage;
