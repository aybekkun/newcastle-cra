import React from "react";

const LessonItem = () => {
  return <div className="lesson__item">LessonItem</div>;
};

export default LessonItem;
